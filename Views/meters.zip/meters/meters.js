
function loadMeterValuesCall(nick) {
  document.getElementById("meterName").innerHTML = nick;
  xproSendUserMessage("loadMeterValues", nick, function(data) {
   if(data==null){
    for (let key of paramKeys) {
      try {
        document.getElementById("param_" + key).innerHTML = "##.##";
        document.getElementById("param_ONLINE").innerHTML =  "OFFLINE";
        document.getElementById("param_ONLINE").className =  "offline";
      } catch (error) {
      }
    }
   }else{
    document.getElementById("param_ONLINE").innerHTML = data["ONLINE"] == 1 ? "ONLINE" : "OFFLINE";
    document.getElementById("param_ONLINE").className = data["ONLINE"] == 1 ? "online" : "offline";
    for (let key of paramKeys) {
      try {
        document.getElementById("param_" + key).innerHTML = data[key] === null ? "##.##" : data[key];
      } catch (error) {
        document.getElementById("param_" + key).innerHTML = "##.##";
      }
    }
   }
  });
}

function loadMeterValues(nick) {
  currentMeter = nick;
  loadMeterValuesCall(nick);
}
var meterNames = [
  "12F AC PANEL METER 1",
  "12F AC PANEL METER 2",
  "11F METER",
  "10F METER",
  "8F METER",
  "6F METER",
  "4F METER",
  "1F METER",
  "GF METER",
  "MAIN LV INCOMING SUPPLY",
  "MAIN LV SPARE",
  "MAIN LV 12F AC OUTDOOR UNIT 1",
  "MAIN LV 12F AC OUTDOOR UNIT 2",
  "MAIN LV ATS",
  "MAIN LV PUMP ROOM",
  "MAIN LV NO LABEL",
  "MAIN LV 11F VRV BOARDS",
  "MAIN LV 12F CHILLER",
  "MAIN LV D4",
  "MAIN LV CAR PARK",
  "MAIN LV SWITCH HSE AND GATE HSE",
  "MAIN LV D6",
  "LV SWITCHBOARD SOLAR 1",
  "LV SWITCHBOARD SOLAR 2",
  "LV SWITCHBOARD SOLAR 3",
  "LV SWITCHBOARD SOLAR 4",
  "LV SWITCHBOARD SOLAR 5",
  "LV SWITCHBOARD SOLAR 6",
  "LV SWITCHBOARD SOLAR 7",
  "LV SWITCHBOARD SOLAR 8",
  "LV SWITCHBOARD SOLAR INCOMING METER",
  "SWITCH HOUSE ATS INCOMER",
  "SWITCH HOUSE PARALLELING PANEL",
  "SWITCH HOUSE AVR 1 INPUT",
  "SWITCH HOUSE AVR 1 OUTPUT",
  "SWITCH HOUSE AVR 2 INPUT",
  "SWITCH HOUSE AVR 2 OUTPUT"
];
var currentMeter = meterNames[0];

var paramKeys = ["V1", "V2", "V3", "I1", "I2", "I3", "KWHI", "FREQ", "PFT", "VART", "VAT", "WT"];

function highlight_row() {
  var table = document.getElementById('meterTable');
  var cells = table.getElementsByTagName('td');

  for (var i = 0; i < cells.length; i++) {
      // Take each cell
      var cell = cells[i];
      // do something on onclick event for cell
      cell.onclick = function () {
          // Get the row id where the cell exists
          var rowId = this.parentNode.rowIndex;

          var rowsNotSelected = table.getElementsByTagName('tr');
          for (var row = 1; row < rowsNotSelected.length; row++) {
              rowsNotSelected[row].style.backgroundColor = "";
              rowsNotSelected[row].classList.remove('selected');
          }
          var rowSelected = table.getElementsByTagName('tr')[rowId];
          rowSelected.style.backgroundColor = "#6cb6df";
          rowSelected.className += " selected";

      }
  }

}


function init() {
  console.log("meter page loaded");
  let mIndex = 1;
  for (let mt of meterNames) {
    document.getElementById("meterList").innerHTML += `<tr onclick="loadMeterValues('${mt}')">
    <td>${mIndex}</td>
    <td>${mt}</td>
    </tr>`;
    mIndex += 1;
  }

highlight_row()
}

async function periodic() {
  // loadMeterValuesCall(currentMeter);
}

function destroy() {
  console.log("meter page destroyed");
}
